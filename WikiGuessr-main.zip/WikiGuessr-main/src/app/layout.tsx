import type { Metadata } from "next";
import { Space_Grotesk, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const spaceGrotesk = Space_Grotesk({
  variable: "--font-sans",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-mono",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "WikiGuessr - Wikipedia Navigation Game",
  description: "Navigate from one Wikipedia article to another using only links. A GeoGuessr-like game for Wikipedia!",
  keywords: ["wikipedia", "game", "navigation", "wiki race", "trivia"],
  authors: [{ name: "WikiGuessr" }],
  openGraph: {
    title: "WikiGuessr - Wikipedia Navigation Game",
    description: "Navigate from one Wikipedia article to another using only links",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body
        className={`${spaceGrotesk.variable} ${jetbrainsMono.variable} font-sans antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
